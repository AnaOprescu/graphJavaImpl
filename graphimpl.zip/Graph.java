/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphimpl;

/**
 *
 * @author ana.maria
 */
public interface Graph {

	/**
	 * method to add an Edge
	 * @param e Edge to add
	 */
	public int addEdge(Edge e);

	/**
	 * method to add a Vertex
	 * @param v Vertex to add
	 */
	public int addVertex(Vertex v);
	
	
	
	
	
	
	
}