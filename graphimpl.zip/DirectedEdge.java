/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphimpl;

/**
 *
 * @author ana.maria
 */
public class DirectedEdge extends Edge{
	private Vertex pointDepart;

	/**
	 * constructor of DirectedEdge
	 * @param a the first vertex of an edge, also the beginning point of the directed Edge
	 * @param b the second vertex of an edge
	 */
	public DirectedEdge(Vertex a, Vertex b){
		super(a, b);
		setPointDepart(a);
	}

	/**
	 * getter of pointDepart
	 * @return value of pointDepart
	 */
	public Vertex getPointDepart() {
		return pointDepart;
	}

	/**
	 * setter of pointDepart
	 * @param pointDepart the value pointDepart will get
	 */
	public void setPointDepart(Vertex pointDepart) {
		this.pointDepart = pointDepart;
	}
}