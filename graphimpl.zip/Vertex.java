/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphimpl;

/**
 *
 * @author ana.maria
 */
public class Vertex {
	private Object objet;

	/**
	 * constructor of Vertex
	 * @param o the Object that represents the Vertex
	 */
	public Vertex(Object o){
		setObjet(o);
	}

	/**
	 * getter of objet
	 * @return value of objet
	 */
	public Object getObjet() {
		return objet;
	}

	/**
	 * setter of objet
	 * @param objet the value objet will get
	 */
	public void setObjet(Object objet) {
		this.objet = objet;
	}
}