/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphimpl;

/**
 *
 * @author ana.maria
 */
public class UndirectedEdge extends Edge{

	/**
	 * constructor of UndirectedEdge
	 * @param a the first vertex of an edge
	 * @param b the second vertex of an edge
	 */
	public UndirectedEdge(Vertex a, Vertex b){
		super(a, b);
	}
}